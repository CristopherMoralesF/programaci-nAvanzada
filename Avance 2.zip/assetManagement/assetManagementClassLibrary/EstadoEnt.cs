﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace assetManagementClassLibrary
{
    public class EstadoEnt
    {
        public int idEstado { get; set; }  
        public string descripcionEstado { get; set; }   

    }
}