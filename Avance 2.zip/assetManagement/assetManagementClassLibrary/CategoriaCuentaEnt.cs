﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace assetManagementClassLibrary
{
    public class CategoriaCuentaEnt
    {
        public int idCategoria { get; set; }
        public string descripcionCategoria { get; set; }

    }
}