﻿using System;
using System.Collections.Generic;

namespace assetManagementClassLibrary.assetManagementDbModel
{
    public partial class EcuacionContable
    {
        public string? Categoria { get; set; }
        public double? TotalBalance { get; set; }
    }
}
