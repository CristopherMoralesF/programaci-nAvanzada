﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace assetManagementClassLibrary
{
    public class UbicacionEnt
    {
        public int idUbicacíon { get; set; }
        public string idEdificio { get; set; }
        public string descripcionSeccion { get; set; }

    }
}